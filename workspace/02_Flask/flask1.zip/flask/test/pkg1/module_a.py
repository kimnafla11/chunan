from flask import Blueprint, render_template

app100 = Blueprint('app100', __name__)

@app100.route("/")
def index() :
    html = render_template('sub1/a.html')
    return html