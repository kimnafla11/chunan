from flask import Flask, render_template, request
from pkg1 import module_a

app = Flask(__name__, template_folder='view')

app.register_blueprint(module_a.app100)

app.run(host='0.0.0.0', port=80)