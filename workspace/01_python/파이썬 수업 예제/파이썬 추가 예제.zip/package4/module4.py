def f7() :
    print('package4 module4 f7')
    
def f8() :
    print('package4 module4 f8')