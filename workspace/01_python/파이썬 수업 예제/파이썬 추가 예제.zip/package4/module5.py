def f9() :
    print('package4 module5 f9')
    
def f10() :
    print('package4 module5 f10')