module2_a1 = 100

def module2_function() :
    print('module2_function')
    
class Module2Class :
    pass