def f3() :
    print('package2 module2 f3')
    
def f4() :
    print('package2 module2 f4')