print('Hello World')
a1 = 10 + 20
print(a1)