module4_a1 = 100

def module4_function() :
    print('module4_function')
    
class Module4Class :
    pass