def f5() :
    print('package3 module3 f5')
    
def f6() :
    print('package3 module3 f6')