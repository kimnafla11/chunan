def f1() :
    print('package1 module1 f1')
    
def f2() :
    print('package1 module1 f2')