module3_a1 = 100

def module3_function() :
    print('module3_function')
    
class Module3Class :
    pass